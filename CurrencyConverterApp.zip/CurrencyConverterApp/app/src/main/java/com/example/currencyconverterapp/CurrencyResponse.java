package com.example.currencyconverterapp;
import java.util.Map;

public class CurrencyResponse {
    private Map<String, Double> rates;

    public Map<String, Double> getRates() {
        return rates;
    }
}
